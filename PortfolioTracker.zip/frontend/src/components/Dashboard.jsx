import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Dashboard = () => {
  const [portfolioValue, setPortfolioValue] = useState(0);
  const [topStock, setTopStock] = useState('');

  useEffect(() => {
    axios.get('/api/stocks').then((response) => {
      const stocks = response.data;
      let totalValue = 0;
      let top = { name: '', value: 0 };
      stocks.forEach((stock) => {
        const value = stock.quantity * stock.buyPrice;
        totalValue += value;
        if (value > top.value) top = { name: stock.name, value };
      });
      setPortfolioValue(totalValue);
      setTopStock(top.name);
    });
  }, []);

  return (
    <div>
      <h1>Portfolio Dashboard</h1>
      <p>Total Portfolio Value: ${portfolioValue}</p>
      <p>Top Performing Stock: {topStock}</p>
    </div>
  );
};

export default Dashboard;